from __future__ import annotations

from abc import ABC, abstractmethod
from pathlib import Path

from sandex.extract_policy import ExtractPolicy
from sandex.handlers.toolSpec import ToolSpec

class ArchiveHandler(ABC):
    @abstractmethod
    def supports(self, archive: Path) -> bool: ...

    @abstractmethod
    def tool(self, archive: Path) -> ToolSpec: ...

    @abstractmethod
    def default_output_name(self, archive: Path) -> str: ...

    def policy(self) -> ExtractPolicy:
        return ExtractPolicy()
