from __future__ import annotations

from pathlib import Path

from sandex.handlers.archiveHandlerABS import ArchiveHandler
from sandex.handlers.toolSpec import ToolSpec


class ZipHandler(ArchiveHandler):
    """ZIP handler using bsdtar."""

    def supports(self, archive: Path) -> bool:
        return archive.name.lower().endswith(".zip")

    def default_output_name(self, archive: Path) -> str:
        return archive.name.removesuffix(".zip")

    def tool(self, archive: Path) -> ToolSpec:
        return ToolSpec(argv=["bsdtar", "-xf", "/in/archive"])
