from __future__ import annotations

from pathlib import Path

from sandex.handlers.archiveHandlerABS import ArchiveHandler
from sandex.handlers.toolSpec import ToolSpec


class TarHandler(ArchiveHandler):
    """
    TAR-family handler using bsdtar.
    Supports: .tar, .tar.gz, .tgz, .tar.bz2, .tbz2, .tar.xz, .txz, .tar.zst, .tzst
    """

    _SUFFIXES = {
        ".tar",
        ".tar.gz", ".tgz",
        ".tar.bz2", ".tbz2",
        ".tar.xz", ".txz",
        ".tar.zst", ".tzst",
    }

    def supports(self, archive: Path) -> bool:
        name = archive.name.lower()
        return any(name.endswith(s) for s in self._SUFFIXES)

    def default_output_name(self, archive: Path) -> str:
        name = archive.name
        lower = name.lower()
        for s in self._SUFFIXES:
            if lower.endswith(s):
                return name[: -len(s)]
        # Fallback (should not happen if supports() is correct)
        return archive.stem

    def tool(self, archive: Path) -> ToolSpec:
        # The sandbox will bind the real archive to /in/archive
        return ToolSpec(argv=["bsdtar", "-xf", "/in/archive"])
