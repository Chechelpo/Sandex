from __future__ import annotations

from pathlib import Path

from sandex.handlers.archiveHandlerABS import ArchiveHandler
from sandex.handlers.toolSpec import ToolSpec

class RarHandler(ArchiveHandler):

    def supports(self, archive:Path) -> bool:
        return archive.suffix.lower() == ".rar"

    def default_output_name(self, archive: Path) -> str:
        return archive.name.removesuffix(".rar")

    def tool(self, archive: Path) -> ToolSpec:
        return ToolSpec(argv=[
            "unrar",
            "x",          # extract with full paths
            "-idq",       # quiet
            "-o-",        # do not overwrite existing files
            "-p-",        # do not prompt for password (fail if encrypted)
            "/in/archive",
            "/out/",
        ])

