Sandboxed file extractor for linux written in Python.
<p>
Dependencies:
    -bwrap: sandbox
    -bsdtar: for zip and tar extraction
</p>
